package project.server.enums.trainResult;

import project.server.enums.interfaces.IResult;

public enum ReservationResult implements IResult {
    SEAT_DUPLICATED,
    NO_MATCH_CNT
    
    
}
