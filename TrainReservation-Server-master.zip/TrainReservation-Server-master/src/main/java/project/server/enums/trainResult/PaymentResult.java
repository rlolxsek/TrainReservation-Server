package project.server.enums.trainResult;

import project.server.enums.interfaces.IResult;

public enum PaymentResult implements IResult {
    IS_COMPLETED_PAYMENT
}
