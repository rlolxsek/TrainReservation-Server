package project.server.enums.member;

import project.server.enums.interfaces.IResult;

public enum EmailSendResult implements IResult {
    NOT_SENDING_EMAIL
}
