package project.server.enums.trainResult;

import project.server.enums.interfaces.IResult;

public enum InquiryResult implements IResult {
    NO_SEARCH_DATA,
    API_ERROR
    
    
}
