package project.server.enums.info;

import project.server.enums.interfaces.IResult;

public enum AnswerInsertResult implements IResult {
    COMPLETED_ANSWER,
    NO_ANSWER
    
}
