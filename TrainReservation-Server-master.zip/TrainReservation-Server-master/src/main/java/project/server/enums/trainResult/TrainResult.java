package project.server.enums.trainResult;

import project.server.enums.interfaces.IResult;

public enum TrainResult implements IResult {
    NO_SEARCH_DATA,
    INVALID_RESERVATION_ID



    }
