package project.server.enums.member;

import project.server.enums.interfaces.IResult;

public enum ExistEmailAndId implements IResult {
    NO_EXIST,
    NO_REGISTER
}
