package project.server.enums.member;

import project.server.enums.interfaces.IResult;

public enum LoginResult implements IResult {
    ID_NO_MATCH,
    PASSWORD_NO_MATCH
}
