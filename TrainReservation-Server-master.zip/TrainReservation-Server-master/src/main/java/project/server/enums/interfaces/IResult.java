package project.server.enums.interfaces;

public interface IResult {
    String name();
}
