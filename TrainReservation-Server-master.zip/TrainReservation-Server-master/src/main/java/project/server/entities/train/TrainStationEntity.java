package project.server.entities.train;

import lombok.Data;

@Data
public class TrainStationEntity {
    private Integer index;
    private String stationName;
    private String stationCode;
}
