package project.server.entities.train;

import lombok.Data;

@Data
public class TrainNoEntity {
    public int index;
    public int trainNo;
}
