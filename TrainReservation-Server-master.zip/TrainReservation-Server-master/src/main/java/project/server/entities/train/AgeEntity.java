package project.server.entities.train;

import lombok.Data;

@Data
public class AgeEntity {
    private int index;
    private String kinds;
    private double discountRate;
}
