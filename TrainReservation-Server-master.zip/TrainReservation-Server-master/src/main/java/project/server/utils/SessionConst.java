package project.server.utils;

public class SessionConst {

    public static final String LOGIN_MEMBER = "loginMember";
    public static final String CNT="reservationCount";
}
